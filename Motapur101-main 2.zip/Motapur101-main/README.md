<!-- index.html (First Page) -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>motapur</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em;
        }

        section {
            padding: 2em;
            text-align: center;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em;
            position: absolute;
            bottom: 0;
            width: 100%;
        }

        button {
            padding: 10px 20px;
            background-color: #ff6600;
            color: #fff;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        a {
            color: #0066cc;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to motapur</h1>
    </header>
    
    <section>
        <h2>About Me and motapur</h2>
        <p>Hi, I'm Mota, the founder of motapur. Here are some points about me and motapur:</p>
        <ul>
            <li>My name is Mota.</li>
            <li>I'm the founder of motapur.</li>
            <li>motapur is a fascinating part of Northern Mars.</li>
            <li>Click <a href="http://localhost:9898/Local/unknown/html/coding.html/html/submit.html?6719D668-FCF0-4447-B1D2-71716C2A1ACD">this link</a> if you want a baby on Mars! (Now you can make babies on Mars in just 2 CR)</li>
        </ul>
    </section>

    <footer>
        <p>&copy; 2023 motapur</p>
    </footer>
</body>
</html>													 <li>Click <a href="http://localhost:9898/Local/motapur77.html?CA2C27FE-87FA-4850-BAC6-AC77DC51E5C8">this link</a>for more information about motapur </li>
        </ul>
    </section>

    <footer>
        <p>&copy; 2023 motapur</p>
    </footer>
</body>
</html>		
